import { Outlet } from "react-router-dom"

const AnotherLayout = () => {

    return (
        <div>
            <div></div>
            <Outlet/>
        </div>
    )
}

export default AnotherLayout