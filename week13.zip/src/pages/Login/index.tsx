import { Login as LoginContainer } from "../../containers";

const Login = () => {

    return (
        <LoginContainer />
    )
}

export default Login