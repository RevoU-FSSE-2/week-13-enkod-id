import { ProductDetail as ProductDetailContainer } from '../../containers';

const ProductDetail = () => {

    return (
        <ProductDetailContainer />
    )
}

export default ProductDetail