
const Category = () => {

    return (
       <h2>Category</h2>
    )
}

export default Category