import { ProductNew as ProductNewContainer } from '../../containers';

const ProductNew = () => {

    return (
        <ProductNewContainer />
    )
}

export default ProductNew