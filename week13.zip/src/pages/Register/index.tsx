import { Register as RegisterContainer } from "../../containers";

const Register = () => {

    return (
        <RegisterContainer />
    )

}

export default Register