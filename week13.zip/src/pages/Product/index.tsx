import { ProductList } from "../../containers";

const Product = () => {

    return (
        <ProductList />
    )
}

export default Product