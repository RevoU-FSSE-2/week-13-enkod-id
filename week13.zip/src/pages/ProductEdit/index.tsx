import { ProductEdit as ProductEditContainer } from '../../containers';

const ProductEdit = () => {

    return (
        <ProductEditContainer />
    )
}

export default ProductEdit