export { default as ProductList } from './ProductList';
export { default as ProductDetail } from './ProductDetail';
export { default as ProductNew } from './ProductNew';
export { default as ProductEdit } from './ProductEdit';
export { default as Login } from './Login';
export { default as Register } from './Register';
